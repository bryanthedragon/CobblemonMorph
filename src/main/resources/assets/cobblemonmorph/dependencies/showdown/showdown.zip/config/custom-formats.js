"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var custom_formats_exports = {};
__export(custom_formats_exports, {
  Formats: () => Formats
});
module.exports = __toCommonJS(custom_formats_exports);
const Formats = [
  {
    section: "Cobblemon"
  },
  {
    name: "Cobblemon Singles",
    threads: [],
    mod: "cobblemon",
    ruleset: [],
    gameType: "singles"
  },
  {
    name: "Cobblemon Doubles",
    threads: [],
    mod: "cobblemon",
    ruleset: [],
    gameType: "doubles"
  },
  {
    name: "Cobblemon Triples",
    threads: [],
    mod: "cobblemon",
    ruleset: [],
    gameType: "triples"
  },
  {
    name: "Cobblemon Rotation",
    threads: [],
    mod: "cobblemon",
    ruleset: [],
    gameType: "rotation"
  },
  {
    name: "Cobblemon Multi",
    threads: [],
    mod: "cobblemon",
    ruleset: [],
    gameType: "multi"
  },
  {
    name: "Cobblemon Free for All",
    threads: [],
    mod: "cobblemon",
    ruleset: [],
    gameType: "freeforall"
  }
];
//# sourceMappingURL=custom-formats.js.map
